/**
 * DemoTelemetryProvider
 * ----------------------
 * Generates realistic laptop telemetry for one of three device health
 * profiles (healthy / aging / at-risk) and submits it through the real
 * `POST /api/telemetry` endpoint — it never writes to Prisma directly.
 *
 * This is a standalone dev/demo tool, not part of the Express app. It logs
 * in through the existing `POST /api/login` route to obtain a JWT, then
 * calls the telemetry API exactly like a real device agent would, except
 * every reading is tagged `source: "demo_simulated"` so it's never
 * confused with genuine agent-reported data.
 *
 * Usage:
 *   npx tsx scripts/demoTelemetryProvider.ts <deviceId> <profile>
 *
 *   <profile> is one of: healthy | aging | at-risk
 *
 * Env vars (all optional, fall back to the seeded dev defaults):
 *   API_BASE_URL          default "http://localhost:4000/api"
 *   DEMO_LOGIN_EMAIL      default "rohit.sharma@acmeglobal.com"
 *   DEMO_LOGIN_PASSWORD   default "password123"
 *
 * Example:
 *   npx tsx scripts/demoTelemetryProvider.ts cljk3x9q10000abcd aging
 */

type Profile = "healthy" | "aging" | "at-risk";

interface Range {
  min: number;
  max: number;
}

interface ProfileRanges {
  battery_health_percent: Range;
  battery_cycle_count: Range;
  ssd_wear_percent: Range;
  ssd_health_percent: Range;
  thermal_event: Range; // count of thermal-throttle events in the reporting window
  cpu_temperature_c: Range;
  ram_usage_percent: Range;
  storage_usage_percent: Range;
}

// Ranges reflect the profile descriptions given in the product spec.
// ram_usage_percent / storage_usage_percent aren't specified there, so
// they're extrapolated to move the same direction as the other metrics
// (a more stressed/aging machine tends to run fuller and busier).
const PROFILE_RANGES: Record<Profile, ProfileRanges> = {
  healthy: {
    battery_health_percent: { min: 90, max: 98 },
    battery_cycle_count: { min: 50, max: 300 },
    ssd_wear_percent: { min: 1, max: 10 },
    ssd_health_percent: { min: 90, max: 99 },
    thermal_event: { min: 0, max: 1 },
    cpu_temperature_c: { min: 45, max: 70 },
    ram_usage_percent: { min: 30, max: 60 },
    storage_usage_percent: { min: 35, max: 65 },
  },
  aging: {
    battery_health_percent: { min: 65, max: 85 },
    battery_cycle_count: { min: 300, max: 700 },
    ssd_wear_percent: { min: 10, max: 30 },
    ssd_health_percent: { min: 70, max: 90 },
    thermal_event: { min: 1, max: 3 },
    cpu_temperature_c: { min: 60, max: 80 },
    ram_usage_percent: { min: 45, max: 75 },
    storage_usage_percent: { min: 55, max: 85 },
  },
  "at-risk": {
    battery_health_percent: { min: 40, max: 65 },
    battery_cycle_count: { min: 700, max: 1200 },
    ssd_wear_percent: { min: 30, max: 60 },
    ssd_health_percent: { min: 40, max: 70 },
    thermal_event: { min: 3, max: 8 },
    cpu_temperature_c: { min: 75, max: 95 },
    ram_usage_percent: { min: 60, max: 90 },
    storage_usage_percent: { min: 80, max: 97 },
  },
};

const UNITS: Record<keyof ProfileRanges, string> = {
  battery_health_percent: "%",
  battery_cycle_count: "cycles",
  ssd_wear_percent: "%",
  ssd_health_percent: "%",
  thermal_event: "events",
  cpu_temperature_c: "C",
  ram_usage_percent: "%",
  storage_usage_percent: "%",
};

// Metrics reported as whole numbers (counts, percentages we don't need decimals for).
const INTEGER_METRICS = new Set<keyof ProfileRanges>([
  "battery_cycle_count",
  "thermal_event",
]);

function randomInRange({ min, max }: Range, asInteger: boolean): number {
  const value = min + Math.random() * (max - min);
  return asInteger ? Math.round(value) : Math.round(value * 10) / 10;
}

function generateReadings(profile: Profile) {
  const ranges = PROFILE_RANGES[profile];
  return (Object.keys(ranges) as (keyof ProfileRanges)[]).map((metricType) => ({
    metricType,
    value: randomInRange(ranges[metricType], INTEGER_METRICS.has(metricType)),
    unit: UNITS[metricType],
  }));
}

async function login(apiBaseUrl: string, email: string, password: string): Promise<string> {
  const res = await fetch(`${apiBaseUrl}/login`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ email, password }),
  });
  if (!res.ok) {
    throw new Error(`Login failed (${res.status}): ${await res.text()}`);
  }
  const data = (await res.json()) as { token: string };
  return data.token;
}

async function submitTelemetry(
  apiBaseUrl: string,
  token: string,
  deviceId: string,
  readings: ReturnType<typeof generateReadings>
) {
  const res = await fetch(`${apiBaseUrl}/telemetry`, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      Authorization: `Bearer ${token}`,
    },
    body: JSON.stringify({ deviceId, source: "demo_simulated", readings }),
  });
  const body = await res.json();
  if (!res.ok) {
    throw new Error(`Telemetry submission failed (${res.status}): ${JSON.stringify(body)}`);
  }
  return body;
}

async function main() {
  const [deviceId, profileArg] = process.argv.slice(2);

  if (!deviceId || !profileArg) {
    console.error("Usage: npx tsx scripts/demoTelemetryProvider.ts <deviceId> <healthy|aging|at-risk>");
    process.exit(1);
  }

  if (!(profileArg in PROFILE_RANGES)) {
    console.error(`Unknown profile "${profileArg}". Expected one of: healthy, aging, at-risk`);
    process.exit(1);
  }
  const profile = profileArg as Profile;

  const apiBaseUrl = process.env.API_BASE_URL ?? "http://localhost:4000/api";
  const email = process.env.DEMO_LOGIN_EMAIL ?? "rohit.sharma@acmeglobal.com";
  const password = process.env.DEMO_LOGIN_PASSWORD ?? "password123";

  const readings = generateReadings(profile);
  console.log(`Generated ${readings.length} "${profile}" readings for device ${deviceId}:`);
  console.table(readings);

  const token = await login(apiBaseUrl, email, password);
  const result = await submitTelemetry(apiBaseUrl, token, deviceId, readings);

  console.log("Submitted via POST /api/telemetry:", result);
}

main().catch((err) => {
  console.error(err instanceof Error ? err.message : err);
  process.exit(1);
});
